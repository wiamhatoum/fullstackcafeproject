import React from 'react'
import '../styles/style.css'
const Home = () => {
  return (
    <div>
        <section class="hero">
          <div class="hero-content">
            <h1>Welcome to LIU</h1>
            <p>Your gateway to the future of education.</p>
            <a href="#about" class="btn">Learn More</a>
          </div>
        </section>

          <section id="departments" class="departments">
    <h2>Departments</h2>
    <div class="dept-cards">
      <div class="card">
        <h3>Computer Science</h3>
        <p>Explore AI, Software Development, and Cybersecurity.</p>
      </div>
      <div class="card">
        <h3>Business</h3>
        <p>Learn Management, Marketing, and Entrepreneurship.</p>
      </div>
      <div class="card">
        <h3>Engineering</h3>
        <p>Innovate in Civil, Mechanical, and Electrical Engineering.</p>
      </div>
    </div>
  </section>

    </div>

    
  )
}

export default Home
