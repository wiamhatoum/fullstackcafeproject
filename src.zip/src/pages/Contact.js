import React from 'react'
import '../styles/style.css'
const Contact = () => {
  return (
    <div>
        <section id="contact" class="contact">
    <h2>Contact Us</h2>
    <p>Email: info@campusconnect.edu | Phone: +1 234 567 890</p>
  </section>
    </div>
  )
}

export default Contact
