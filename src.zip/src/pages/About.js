import React from 'react'
import '../styles/style.css'

const About = () => {
  return (
    <div>
       <section id="about" class="about">
    <h2>About Our Campus</h2>
    <p>
      CampusConnect brings together modern facilities, experienced faculty, and a vibrant student community. Whether you're here to learn, grow, or lead – this is where your journey begins.
    </p>
  </section>




    </div>
  )
}

export default About
