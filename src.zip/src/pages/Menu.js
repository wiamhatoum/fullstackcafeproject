import React from 'react'
import  '../App.css'

import Beirut from '../assets/Beirut.jpg'
import Akkar from '../assets/Akkar.jpg'
import Bekaa from '../assets/Bekaa.jpg'
import MountLebanon from '../assets/MountLebanon.jpg'
import Rayak from '../assets/Rayak.jpg'
import Saida from '../assets/Saida.jpg'
import '../styles/style.css'

const menu = () => {
  return (
     <div className='campus'>
     
         


    </div>
  )
}

export default menu
