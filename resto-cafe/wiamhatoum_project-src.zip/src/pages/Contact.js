import React from 'react'
import '../styles/style.css'
const Contact = () => {
  return (
    <div>
        <section id="contact" class="contact">
    <h2>Contact Us</h2>
    <p>Email: champ-restoandcafe@gmail.com </p>
       <p>Phone: +961 71 452 442</p>
  </section>
    </div>
  )
}

export default Contact;
